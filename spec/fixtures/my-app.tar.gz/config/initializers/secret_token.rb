# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
MyApp::Application.config.secret_token = 'eca5a479c718a9476893230063b1279204a0a1c78817f1236da83fc8a85563b65210e4fdd69a5b4a1bc8b7bdcb64412e61a9224f5358248a57421fd68d25b4a2'
